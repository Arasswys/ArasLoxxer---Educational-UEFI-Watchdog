#include <efi.h>
#include <efilib.h>
#include <efiapi.h>

// Log yazma yardımcı fonksiyonu (Hata veren VA_LIST kaldırıldı)
// Artık formatlı metni dışarıda hazırlayıp buraya göndereceğiz.
void WriteLog(EFI_FILE_HANDLE LogFile, CHAR16 *Message) {
    UINTN WriteSize = StrLen(Message) * 2;
    uefi_call_wrapper(LogFile->Write, 3, LogFile, &WriteSize, Message);
}

EFI_FILE_HANDLE GetVolume(EFI_HANDLE Image) {
    EFI_LOADED_IMAGE *LoadedImage = NULL;
    EFI_GUID lipGuid = EFI_LOADED_IMAGE_PROTOCOL_GUID;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Volume;
    EFI_FILE_HANDLE RootDir;
    uefi_call_wrapper(BS->HandleProtocol, 3, Image, &lipGuid, (void**)&LoadedImage);
    uefi_call_wrapper(BS->HandleProtocol, 3, LoadedImage->DeviceHandle, &FileSystemProtocol, (void**)&Volume);
    uefi_call_wrapper(Volume->OpenVolume, 2, Volume, &RootDir);
    return RootDir;
}

EFI_STATUS
EFIAPI
efi_main (EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable)
{
    InitializeLib(ImageHandle, SystemTable);
    uefi_call_wrapper(ST->ConOut->ClearScreen, 1, ST->ConOut);
    
    Print(L"\r\n[!] ARASLOXXER TAM KAPSAMLI KASIF (REAL HW SCANNER)\r\n");
    Print(L"[*] Sistem DNA'si cikariliyor...\r\n");

    EFI_FILE_HANDLE RootDir = GetVolume(ImageHandle);
    EFI_FILE_HANDLE LogFile;
    uefi_call_wrapper(RootDir->Open, 5, RootDir, &LogFile, L"ArasLoxxer_Ultimate.txt", EFI_FILE_MODE_CREATE | EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE, 0);

    CHAR16 LogBuf[512];

    // 1. FİRMWARE VE SİSTEM BİLGİLERİ
    WriteLog(LogFile, L"=== ARASLOXXER ULTIMATE SYSTEM SCAN ===\r\n\r\n");
    WriteLog(LogFile, L"--- FIRMWARE INFO ---\r\n");
    
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"Vendor: %s\r\n", ST->FirmwareVendor);
    WriteLog(LogFile, LogBuf);
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"Revision: %d\r\n", ST->FirmwareRevision);
    WriteLog(LogFile, LogBuf);
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"UEFI Rev: %d\r\n", ST->Hdr.Revision);
    WriteLog(LogFile, LogBuf);

    // 2. SİSTEM ZAMANI
    EFI_TIME Time;
    uefi_call_wrapper(RT->GetTime, 2, &Time, NULL);
    WriteLog(LogFile, L"\r\n--- TIME INFO ---\r\n");
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"Boot Time: %04d-%02d-%02d %02d:%02d:%02d\r\n", Time.Year, Time.Month, Time.Day, Time.Hour, Time.Minute, Time.Second);
    WriteLog(LogFile, LogBuf);

    // 3. BELLEK HARİTASI (MEMORY MAP)
    UINTN MemoryMapSize = 0;
    EFI_MEMORY_DESCRIPTOR *MemoryMap = NULL;
    UINTN MapKey, DescriptorSize;
    UINT32 DescriptorVersion;
    
    uefi_call_wrapper(BS->GetMemoryMap, 5, &MemoryMapSize, MemoryMap, &MapKey, &DescriptorSize, &DescriptorVersion);
    MemoryMapSize += 2 * DescriptorSize;
    uefi_call_wrapper(BS->AllocatePool, 3, EfiLoaderData, MemoryMapSize, (void**)&MemoryMap);
    uefi_call_wrapper(BS->GetMemoryMap, 5, &MemoryMapSize, MemoryMap, &MapKey, &DescriptorSize, &DescriptorVersion);
    
    WriteLog(LogFile, L"\r\n--- MEMORY MAP ---\r\n");
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"Total Map Size: %d bytes\r\n", MemoryMapSize);
    WriteLog(LogFile, LogBuf);
    UnicodeSPrint(LogBuf, sizeof(LogBuf), L"Descriptor Size: %d bytes\r\n", DescriptorSize);
    WriteLog(LogFile, LogBuf);
    uefi_call_wrapper(BS->FreePool, 1, MemoryMap);

    // 4. PCI CİHAZLARINI TARA (Gerçek Donanım)
    WriteLog(LogFile, L"\r\n--- PCI DEVICES ---\r\n");
    EFI_HANDLE *HandleBuffer = NULL;
    UINTN HandleCount = 0;
    EFI_GUID pciGuid = { 0x4d3a8e5f, 0xb8f0, 0x4b3b, { 0x9b, 0x7e, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc } };
    
    EFI_STATUS Status = uefi_call_wrapper(BS->LocateHandleBuffer, 5, ByProtocol, &pciGuid, NULL, &HandleCount, &HandleBuffer);
    if (Status == EFI_SUCCESS) {
        UnicodeSPrint(LogBuf, sizeof(LogBuf), L"PCI Root Bridges Found: %d\r\n", HandleCount);
        WriteLog(LogFile, LogBuf);
        uefi_call_wrapper(BS->FreePool, 1, HandleBuffer);
    } else {
        UnicodeSPrint(LogBuf, sizeof(LogBuf), L"PCI scan failed (Status: 0x%X)\r\n", Status);
        WriteLog(LogFile, LogBuf);
    }

    // 5. SMBIOS (ANAKART BİLGİLERİ) TARAMASI
    WriteLog(LogFile, L"\r\n--- SMBIOS INFO ---\r\n");
    EFI_GUID smbiosGuid = SMBIOS_TABLE_GUID;
    EFI_CONFIGURATION_TABLE *ConfigTable = ST->ConfigurationTable;
    BOOLEAN SmbiosFound = FALSE;
    for (UINTN i = 0; i < ST->NumberOfTableEntries; i++) {
        if (CompareGuid(&ConfigTable[i].VendorGuid, &smbiosGuid)) {
            UnicodeSPrint(LogBuf, sizeof(LogBuf), L"SMBIOS Table Address: 0x%X\r\n", (UINT64)ConfigTable[i].VendorTable);
            WriteLog(LogFile, LogBuf);
            SmbiosFound = TRUE;
            break;
        }
    }
    if (!SmbiosFound) WriteLog(LogFile, L"SMBIOS Table Not Found.\r\n");

    // 6. KLAVYE NÖBETİ
    WriteLog(LogFile, L"\r\n--- KLAVYE NOBETI BASLADI (Cikis: exit) ---\r\n");
    Print(L"[*] Klavye dinleniyor... (Cikis: exit)\r\n");

    EFI_INPUT_KEY Key;
    CHAR16 KeyBuffer[10] = {0};
    UINTN KeyIndex = 0;

    while (1) {
        if (uefi_call_wrapper(ST->ConIn->ReadKeyStroke, 2, ST->ConIn, &Key) == EFI_SUCCESS) {
            if (Key.UnicodeChar != 0) {
                Print(L"%c", Key.UnicodeChar);
                uefi_call_wrapper(RT->GetTime, 2, &Time, NULL);
                
                // Tuş vuruşlarını logla
                UnicodeSPrint(LogBuf, sizeof(LogBuf), L"[%02d:%02d:%02d] KEY: %c (Scan: 0x%04X)\r\n", 
                         Time.Hour, Time.Minute, Time.Second, Key.UnicodeChar, Key.ScanCode);
                WriteLog(LogFile, LogBuf);
                
                KeyBuffer[KeyIndex++] = Key.UnicodeChar;
                if (KeyIndex >= 4 && KeyBuffer[KeyIndex-4]==L'e' && KeyBuffer[KeyIndex-3]==L'x' && KeyBuffer[KeyIndex-2]==L'i' && KeyBuffer[KeyIndex-1]==L't') break;
                if (KeyIndex >= 9) KeyIndex = 0;
            }
        }
        uefi_call_wrapper(BS->Stall, 1, 50000);
    }

    WriteLog(LogFile, L"--- NOBETCI KAPATILDI ---\r\n");
    uefi_call_wrapper(LogFile->Flush, 1, LogFile);
    uefi_call_wrapper(LogFile->Close, 1, LogFile);
    uefi_call_wrapper(RootDir->Close, 1, RootDir);

    Print(L"\r\n[+] Loglar kaydedildi: ArasLoxxer_Ultimate.txt\r\n");
    Print(L"[+] Windows'a devrediliyor...\r\n");
    uefi_call_wrapper(BS->Stall, 1, 2000000);
    
    return EFI_SUCCESS;
}
